package VFS.core;

public interface VirtualFileSystem {

    byte[] getBytesForBlockId(long blockId) throws IllegalArgumentException;

    long getNextFreeBlock() throws OutOfMemoryError;

    void setBlockContents(byte[] contents, long blockId);

    long getNumberOfFreeBlocks();

    long getTotalSize();

    long getFreeSpace();

    int getBlockSize();

    boolean deleteBlock(long blockid);
}
