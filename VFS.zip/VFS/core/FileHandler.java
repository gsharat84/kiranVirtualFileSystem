package VFS.core;

import VFS.Entities.User;

public abstract class FileHandler {
    protected final VirtualFileSystem virtualFileSystem;
    protected final INodeDao iNodeDao;
    protected final String fileName;
    protected final User user;

    public FileHandler(VirtualFileSystem virtualFileSystem, INodeDao iNodeDao, String fileName, User user) {
        this.virtualFileSystem = virtualFileSystem;
        this.iNodeDao = iNodeDao;
        this.fileName = fileName;
        this.user = user;
    }

    public abstract void open(boolean write);

    public abstract void writeFile(byte[] contents);

    public abstract byte[] readFile();

    public abstract void changeOwner(User newUser);

    public abstract void delete();

    public abstract void close();
}
