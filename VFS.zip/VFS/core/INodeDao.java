package VFS.core;

import VFS.Entities.INode;

public interface INodeDao {

    INode getINode(String fileName);

    INode setINode(String fileName, INode iNode);
}
