package VFS.Entities;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Set;

@Getter
public class Permissions {
    private final UsersWithPermission readPermissions;
    private final UsersWithPermission writePermissions;
    private final UsersWithPermission executePermissions;

    public Permissions(UsersWithPermission readPermissions, UsersWithPermission writePermissions, UsersWithPermission executePermissions) {
        this.readPermissions = readPermissions;
        this.writePermissions = writePermissions;
        this.executePermissions = executePermissions;
    }

    public static class UsersWithPermission{
        private Set<String> userNames;
        private Set<String> userGroups;

        public UsersWithPermission(Set<String> userNames, Set<String> userGroups) {
            this.userNames = userNames;
            this.userGroups = userGroups;
        }

        public Set<String> getUserNames() {
            return userNames;
        }

        public void setUserNames(Set<String> userNames) {
            this.userNames = userNames;
        }

        public Set<String> getUserGroups() {
            return userGroups;
        }

        public void setUserGroups(Set<String> userGroups) {
            this.userGroups = userGroups;
        }
    }

}
