package VFS.Entities;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class User {
    private final String userName;
    private final String userGroup;

    public User(String userName, String userGroup) {
        this.userName = userName;
        this.userGroup = userGroup;
    }
}
