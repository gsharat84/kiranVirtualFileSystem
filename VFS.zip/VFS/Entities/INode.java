package VFS.Entities;

import lombok.AllArgsConstructor;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@AllArgsConstructor
public class INode {
    private String fileName;
    private long fileSizeInBytes;
    private Permissions permissions;
    private List<Long> blockIds;
    private AtomicBoolean writeLock = new AtomicBoolean(false);


    public INode(String fileName) {
        this.fileName = fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setFileSizeInBytes(long fileSizeInBytes) {
        this.fileSizeInBytes = fileSizeInBytes;
    }

    public void setPermissions(Permissions permissions) {
        this.permissions = permissions;
    }

    public void setBlockIds(List<Long> blockIds) {
        this.blockIds = blockIds;
    }

    public INode(String fileName, long fileSizeInBytes, Permissions permissions, List<Long> blockIds) {
        this.fileName = fileName;
        this.fileSizeInBytes = fileSizeInBytes;
        this.permissions = permissions;
        this.blockIds = blockIds;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSizeInBytes() {
        return fileSizeInBytes;
    }

    public Permissions getPermissions() {
        return permissions;
    }

    public List<Long> getBlockIds() {
        return blockIds;
    }

    public void setAtomicBoolean(AtomicBoolean atomicBoolean) {
        this.writeLock = atomicBoolean;
    }

    public AtomicBoolean getWriteLock() {

        return writeLock;
    }
}
