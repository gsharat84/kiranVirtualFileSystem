package VFS.Entities;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class BlockContents {
    private byte[] bytes;
    private int toValueOflastArray;

    public byte[] getBytes() {
        return bytes;
    }

    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }

    public int getToValueOflastArray() {
        return toValueOflastArray;
    }

    public void setToValueOflastArray(int toValueOflastArray) {
        this.toValueOflastArray = toValueOflastArray;
    }
}
