package VFS.exception;

public class InvalidBlockLengthError extends RuntimeException {
}
