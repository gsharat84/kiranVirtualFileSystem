package VFS;

import VFS.Entities.User;
import VFS.core.FileHandler;
import VFS.core.INodeDao;
import VFS.core.VirtualFileSystem;
import VFS.impl.ImMemoryINodeDao;
import VFS.impl.InMemoryVFS;
import VFS.impl.SimpleFileHandler;

public class Driver {
    private VirtualFileSystem virtualFileSystem;

    public static void main(String[] args) throws InterruptedException {
        VirtualFileSystem virtualFileSystem = new InMemoryVFS(10, 11);
        INodeDao iNodeDao = new ImMemoryINodeDao();
        User user = new User("kiran", "froup1");

        FileHandler fileHandler = new SimpleFileHandler(virtualFileSystem, iNodeDao, "abc", user);
        fileHandler.open(true);
        fileHandler.writeFile("my name is kiran".getBytes());
        fileHandler.close();


        FileHandler fileHandler2 = new SimpleFileHandler(virtualFileSystem, iNodeDao, "abc", user);
        fileHandler2.open(false);
        byte[] res = fileHandler2.readFile();
        System.out.println(res.length);
        System.out.println(new String(res));


        FileHandler fileHandler3 = new SimpleFileHandler(virtualFileSystem, iNodeDao, "kiran", user);
        fileHandler3.open(true);
        fileHandler3.writeFile("my name is kiran and i am an indian".getBytes());
        fileHandler3.close();

        FileHandler fileHandler4 = new SimpleFileHandler(virtualFileSystem, iNodeDao, "kiran", user);
        fileHandler4.open(false);
        byte[] res2 = fileHandler4.readFile();
        System.out.println(res2.length);
        System.out.println(new String(res2));
    }
}
