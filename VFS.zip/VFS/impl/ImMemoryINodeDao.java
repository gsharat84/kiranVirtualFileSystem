package VFS.impl;

import VFS.Entities.INode;
import VFS.core.INodeDao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ImMemoryINodeDao implements INodeDao {
    private final Map<String, INode> iNodeMap = new ConcurrentHashMap<>();

    @Override
    public INode getINode(String fileName) {
        return iNodeMap.get(fileName);
    }

    @Override
    public INode setINode(String fileName, INode iNode) {
        return iNodeMap.put(fileName, iNode);
    }
}
