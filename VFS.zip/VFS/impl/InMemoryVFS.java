package VFS.impl;

import VFS.Entities.BlockContents;
import VFS.core.VirtualFileSystem;
import VFS.exception.InvalidBlockLengthError;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryVFS implements VirtualFileSystem {
    private final long numBlocks;
    private final int blockSize;
    private final Map<Long, BlockContents> blockContentsMap = new ConcurrentHashMap<>();
    private final Queue<Long> freeBlocks;

    public InMemoryVFS(long numBlocks, int blockSize)  {
        this.numBlocks = numBlocks;
        this.blockSize = blockSize;
        this.freeBlocks = new LinkedList<>();

        for(long i = 0; i < numBlocks; i++){
            freeBlocks.offer(i);
            blockContentsMap.put(i, new BlockContents());
        }
    }

    @Override
    public byte[] getBytesForBlockId(long blockId) throws IllegalArgumentException {
        if(blockContentsMap.containsKey(blockId)){
            return (blockContentsMap.get(blockId)).getBytes();
        }
        throw new IllegalArgumentException("No block found for the block id " + blockId);
    }

    @Override
    public long getNextFreeBlock() throws OutOfMemoryError {
        if(freeBlocks.isEmpty()){
            throw new OutOfMemoryError();
        }

        return freeBlocks.poll();
    }

    @Override
    public void setBlockContents(byte[] contents, long blockId) {
        checkBlockSize(contents);
        if(blockContentsMap.containsKey(blockId)){
            blockContentsMap.get(blockId).setBytes(contents);
        } else {
            throw new IllegalArgumentException("No block found for the block id " + blockId);
        }
    }

    @Override
    public long getNumberOfFreeBlocks() {
        return freeBlocks.size();
    }

    @Override
    public long getTotalSize() {
        return this.numBlocks* this.blockSize;
    }

    @Override
    public long getFreeSpace() {
        return this.freeBlocks.size() * this.blockSize;
    }

    @Override
    public int getBlockSize() {
        return this.blockSize;
    }

    @Override
    public boolean deleteBlock(long blockid) {
        return this.freeBlocks.offer(blockid);
    }

    private boolean checkBlockSize(byte[] contents){
        if(contents.length != this.blockSize){
            throw new InvalidBlockLengthError();
        }

        return true;
    }
}
