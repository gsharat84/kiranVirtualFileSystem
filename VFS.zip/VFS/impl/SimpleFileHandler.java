package VFS.impl;

import VFS.Entities.INode;
import VFS.Entities.User;
import VFS.core.FileHandler;
import VFS.core.INodeDao;
import VFS.core.VirtualFileSystem;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class SimpleFileHandler extends FileHandler {
    private INode iNode;

    public SimpleFileHandler(VirtualFileSystem virtualFileSystem, INodeDao iNodeDao, String fileName, User user) {
        super(virtualFileSystem, iNodeDao, fileName, user);
    }

    @Override
    public void open(boolean write) {
        this.iNode = this.iNodeDao.getINode(this.fileName);
        if(write && this.iNode != null){
            throw new IllegalArgumentException("Cant write to existing file");
        }
        if(this.iNode == null){
            this.iNode = new INode(fileName);
        }
        if(iNode.getWriteLock().get()){
            throw new RuntimeException("File is already open. Cant edit");
        }
        iNode.getWriteLock().getAndSet(true);
    }

    @Override
    public void writeFile(byte[] contents) {
        List<Long> blockIds = new ArrayList<>();
        long fileSizeInBytes = 0l;
        int blockSize = virtualFileSystem.getBlockSize();
        int i =0;
        int j = blockSize;
        while(j < contents.length){
            byte[] aBlock = new byte[blockSize];
            System.arraycopy(contents, i, aBlock, 0, blockSize);
            long blockId = virtualFileSystem.getNextFreeBlock();
            virtualFileSystem.setBlockContents(aBlock, blockId);
            i = i + blockSize;
            j = j + blockSize;
            blockIds.add(blockId);
            fileSizeInBytes += blockSize;
        }

        if(j != contents.length) {
            byte[] aBlock = new byte[blockSize];
            System.arraycopy(contents, i, aBlock, 0, contents.length - i);
            long blockId = virtualFileSystem.getNextFreeBlock();
            virtualFileSystem.setBlockContents(aBlock, blockId);
            blockIds.add(blockId);
            fileSizeInBytes += blockSize;
        }

        iNode.setBlockIds(blockIds);
        iNode.setFileSizeInBytes(fileSizeInBytes);

    }

    @Override
    public byte[] readFile() {
       ByteBuffer bb =  ByteBuffer.allocate(iNode.getBlockIds().size() * virtualFileSystem.getBlockSize());
       for(long blockId : iNode.getBlockIds()){
           bb.put(virtualFileSystem.getBytesForBlockId(blockId));
       }

       return bb.array();
    }

    @Override
    public void changeOwner(User newUser) {

    }

    @Override
    public void delete() {
        if(iNode.getWriteLock().get()) {
            for (long blockId : iNode.getBlockIds()) {
                virtualFileSystem.deleteBlock(blockId);
            }
            iNodeDao.setINode(this.fileName, null);
        }
    }

    @Override
    public void close() {
        iNodeDao.setINode(fileName, iNode);
        iNode.getWriteLock().set(false);
    }
}
